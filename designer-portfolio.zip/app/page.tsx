"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { PageLoader } from "@/components/page-loader"
import { AnimatedTestimonials } from "@/components/animated-testimonials"
import { AnimatedProjectCard } from "@/components/animated-project-card"
import { AnimatedSmallProjectCard } from "@/components/animated-small-project-card"

export default function Home() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null)
  const [testimonialPage, setTestimonialPage] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const projects = [
    {
      id: 1,
      title: "Fintech Mobile App",
      description: "AUTOMATING FINANCE THINGS • 2023",
      image: "/placeholder.svg?height=800&width=800",
      slug: "fintech-app",
    },
    {
      id: 2,
      title: "E-commerce Platform",
      description: "BUILDING SHOPPING EXPERIENCES • 2022",
      image: "/placeholder.svg?height=800&width=800",
      slug: "ecommerce-platform",
    },
    {
      id: 3,
      title: "Healthcare Dashboard",
      description: "VISUALIZING PATIENT DATA • 2023",
      image: "/placeholder.svg?height=800&width=800",
      slug: "healthcare-dashboard",
    },
    {
      id: 4,
      title: "Social Media App",
      description: "CONNECTING COMMUNITIES • 2022",
      image: "/placeholder.svg?height=800&width=800",
      slug: "social-media-app",
    },
    {
      id: 5,
      title: "Productivity Tool",
      description: "ENHANCING WORK EFFICIENCY • 2023",
      image: "/placeholder.svg?height=800&width=800",
      slug: "productivity-tool",
    },
    {
      id: 6,
      title: "Travel Booking Platform",
      description: "SIMPLIFYING TRAVEL PLANNING • 2022",
      image: "/placeholder.svg?height=800&width=800",
      slug: "travel-booking",
    },
  ]

  const smallProjects = [
    {
      id: 7,
      title: "PatchRx",
      description: "HELPING PEOPLE TRACK MEDICINE",
      logo: "/placeholder.svg?height=100&width=100",
      slug: "patchrx",
    },
    {
      id: 8,
      title: "GitHub",
      description: "SPEEDING UP DESIGNER WORKFLOWS",
      logo: "/placeholder.svg?height=100&width=100",
      slug: "github",
    },
    {
      id: 9,
      title: "Starbucks",
      description: "SHARING DRINKS WITH FRIENDS",
      logo: "/placeholder.svg?height=100&width=100",
      slug: "starbucks",
    },
  ]

  const testimonials = [
    {
      quote:
        "Emil's design approach transformed our product. He has a unique ability to balance aesthetics with functionality.",
      author: "Maria Petrova",
      role: "Product Lead, TechStart Bulgaria",
    },
    {
      quote: "Working with Emil was a game-changer for our startup. User engagement increased by 40% after launch.",
      author: "Stefan Ivanov",
      role: "CEO, HealthTech Solutions",
    },
    {
      quote:
        "Emil brings both creativity and strategic thinking to every project. His designs are backed by solid research.",
      author: "Ana Dimitrova",
      role: "Marketing Director, Global Retail",
    },
    {
      quote: "What sets Emil apart is his ability to translate complex requirements into intuitive user experiences.",
      author: "Viktor Petrov",
      role: "CTO, FinanceWise",
    },
    {
      quote: "Emil's attention to detail and user-centered approach resulted in a product our customers love to use.",
      author: "Elena Todorova",
      role: "UX Director, Digital Agency",
    },
    {
      quote:
        "The design system Emil created has significantly improved our development efficiency and product consistency.",
      author: "Nikolay Georgiev",
      role: "Lead Developer, SaaS Platform",
    },
  ]

  // Calculate how many pages of testimonials we have (showing 3 per page)
  const totalPages = Math.ceil(testimonials.length / 3)

  // Auto-rotate testimonials every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialPage((prev) => (prev + 1) % totalPages)
    }, 5000)

    return () => clearInterval(interval)
  }, [totalPages])

  // Get current testimonials to display (3 at a time)
  const currentTestimonials = testimonials.slice(testimonialPage * 3, testimonialPage * 3 + 3)

  // Handle manual navigation
  const nextTestimonials = () => {
    setTestimonialPage((prev) => (prev + 1) % totalPages)
  }

  const prevTestimonials = () => {
    setTestimonialPage((prev) => (prev - 1 + totalPages) % totalPages)
  }

  return (
    <div className="min-h-screen bg-[#f8f5f2] text-[#2d2d2d]">
      <PageLoader />

      <header className="fixed top-0 left-0 right-0 z-50 border-b border-black/10 bg-[#f8f5f2]/80 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="text-xl font-medium">
            EMIL DONCHEV
          </Link>
          <nav className="flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:text-black/70 transition-colors">
              HOME
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-black/70 transition-colors">
              ABOUT
            </Link>
            <Link href="/blog" className="text-sm font-medium hover:text-black/70 transition-colors">
              BLOG
            </Link>
            <Link href="/cv" className="text-sm font-medium hover:text-black/70 transition-colors">
              CV
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-black/70 transition-colors">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                <path d="M2 12h20" />
              </svg>
            </Link>
          </nav>
        </div>
      </header>

      <main className="pt-24 pb-20">
        {/* Hero Section */}
        <section className="container mx-auto px-6 mb-16">
          <div className="max-w-4xl">
            <h1
              className={`text-7xl md:text-8xl font-bold mb-8 leading-tight transition-all duration-500 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"
              }`}
            >
              Emil Donchev
            </h1>
            <p
              className={`text-xl md:text-2xl text-black/70 mb-6 transition-all duration-500 delay-100 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"
              }`}
            >
              PRODUCT DESIGNER BASED IN PLOVDIV, BULGARIA
            </p>
            <p
              className={`text-xl md:text-2xl text-black/70 transition-all duration-500 delay-200 ${
                isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"
              }`}
            >
              Experienced Product Designer with a strong focus on user-centric design and problem-solving. I create
              scalable, user-centric solutions that address real business needs.
            </p>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="container mx-auto px-6 mb-24">
          <AnimatedTestimonials testimonials={testimonials} />
        </section>

        <section className="container mx-auto px-6 mb-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.slice(0, 4).map((project) => (
              <AnimatedProjectCard
                key={project.id}
                id={project.id}
                title={project.title}
                description={project.description}
                image={project.image}
                slug={project.slug}
              />
            ))}
          </div>
        </section>

        <section className="container mx-auto px-6 mb-24">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {smallProjects.map((project) => (
              <AnimatedSmallProjectCard
                key={project.id}
                id={project.id}
                title={project.title}
                description={project.description}
                logo={project.logo}
                slug={project.slug}
              />
            ))}
          </div>
        </section>

        <section className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.slice(4, 6).map((project) => (
              <AnimatedProjectCard
                key={project.id}
                id={project.id}
                title={project.title}
                description={project.description}
                image={project.image}
                slug={project.slug}
              />
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-black/10 py-6">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-black/70">© 2025 Emil Donchev. All rights reserved.</div>
            <div className="flex items-center space-x-6">
              <Link href="https://twitter.com" className="text-black/70 hover:text-black transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="https://dribbble.com" className="text-black/70 hover:text-black transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94" />
                  <path d="M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32" />
                  <path d="M8.56 2.75c4.37 6 6 9.42 8 17.72" />
                </svg>
                <span className="sr-only">Dribbble</span>
              </Link>
              <Link href="https://linkedin.com" className="text-black/70 hover:text-black transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                  <rect width="4" height="12" x="2" y="9" />
                  <circle cx="4" cy="4" r="2" />
                </svg>
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

